import arcpy
import csv
import os
import sys
import datetime
import json
import time
from arcgis.gis import GIS
from arcgis.mapping import WebMap

searchResult1 = None
layerobj =None
log_path = r'E:\Cyient\Users\Sunil\Read_servicesportal_log'

def readlayersfromWebmap(serlyrs):
    for i in serlyrs:
        if i.layerType == 'GroupLayer':
            for j in i.layers:
                print(servicename +' Layer Title: '+j.title,"ItemID: "+j.itemId,"ID: "+j.id)
        else:
            print(servicename +' Layer Title: '+i.title,"ItemID: "+i.itemId,"ID: "+i.id)
lyrsobj=None          
def getportalservice(servicename):
    global layerobj
    global searchResult1
    global lyrsobj
    gis=GIS('home')
    lyrs=gis.content.search(query="title:"+servicename,item_type="Feature Layer")
    lyrsobj=lyrs 
    searchResult = next((f for f in lyrs if f.title.upper()==servicename.upper()),None)
    searchResult1 =searchResult
    if searchResult:
        lyrs=searchResult.layers
        if lyrs:
            for i in lyrs:
                layerobj = i
                log_file.write(searchResult.title+','+searchResult.url+','+searchResult.itemid+','+i.properties.name+','+str(i.properties.id)+','+str(i.properties.minScale)+','+str(i.properties.maxScale) + '\n')
                print(searchResult.title+','+searchResult.url+','+searchResult.itemid+','+i.properties.name+','+str(i.properties.id)+','+str(i.properties.minScale)+','+str(i.properties.maxScale))
                #print(i)
                #print(servicename +' Layer Name: '+i.properties.name,"ID: "+str(i.properties.id),"maxScale: "+str(i.properties.maxScale))
        ltables=searchResult.tables
        if ltables:
            for i in ltables:
                log_file.write(searchResult.title+','+searchResult.url+','+searchResult.itemid+','+i.properties.name+','+str(i.properties.id) +'\n')
                print(searchResult.title+','+searchResult.url+','+searchResult.itemid+','+i.properties.name+','+str(i.properties.id))
    else:
        log_file.write(servicename + ' Service not found')
log_file = open(os.path.join(log_path,datetime.datetime.now().strftime('PortalItems_%H_%M_%d_%m_%Y.csv')),'w+',buffering=1)
print('MapServiceName,Serfvice URL,Portal Item ID,Layer Name,Layer ID,Min Scale,Max Scale')
log_file.write('MapServiceName,Serfvice URL,Portal Item ID,Layer Name,Layer ID,Min Scale,Max Scale\n')

serviceList =['COR]
for i in serviceList:
    getportalservice(i)

log_file.close()
#getportalservice('NHPELE_NETWORK')


