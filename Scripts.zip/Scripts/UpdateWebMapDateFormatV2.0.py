##Sample of updating existing web map containing hosted feature layers with date fields

from arcgis.mapping import WebMap
from arcgis.gis import GIS


print("Portal access")

gis = GIS("https://dv-gis.dev.southernwater.co.uk/portal", "portaladmin", "SouthernWater2022Dev", verify_cert=False)  #(url_gis, user, pwd, verify_cert=False)
print("Accessing Webmap")
webmap_search = gis.content.search("08c4c749774a41738355c0a9174c3385")

print("Process Started")



edit_tracking_date_fields = ['created_date', 'last_edited_date']

for item in webmap_search:
    item_data = item.get_data()
    field_infos = item_data['layers'][0]['popupInfo']['fieldInfos']
    for field in field_infos:
        if field['fieldName'] in edit_tracking_date_fields:
            print("Changed")
            print(field.fieldName)
            field['format'] = {}
            field['format']['dateFormat'] = 'shortDateLEShortTime'
            field['format']['timizone'] = 'utc'
    item_properties = {"text": json.dumps(item_data)}
    item.update(item_properties=item_properties)
    
for webmap_item in webmap_search:
    webMap = WebMap(webmap_item)
    for table in webMap.tables:
##        print(table.url)
        if hasattr(table, 'popupInfo'):
            popupInfo = table.popupInfo
            if hasattr(popupInfo, 'fieldInfos'):
                fieldInfo = popupInfo.fieldInfos
                for field in fieldInfo:
                    if hasattr(field, 'format'):
                        format = field.format
                        if hasattr(format, 'dateFormat'):
                            dateFormat = format.dateFormat
                            if dateFormat != 'shortDateLEShortTime':
                                print("Changed")
                                print(table.url)
                                print(field.fieldName)
                                field.format.dateFormat = 'shortDateLEShortTime'
    for layer in webMap.layers:
##        print(layer.url)
        if hasattr(layer, 'popupInfo'):
            popupInfo = layer.popupInfo
            if hasattr(popupInfo, 'fieldInfos'):
                fieldInfo = popupInfo.fieldInfos
                for field in fieldInfo:
                    if hasattr(field, 'format'):
                        format = field.format
                        if hasattr(format, 'dateFormat'):
                            dateFormat = format.dateFormat
                            if dateFormat != 'shortDateLEShortTime':
                                print("Changed")
                                print(layer.url)
                                print(field.fieldName)
                                field.format.dateFormat = 'shortDateLEShortTime'
    webMap.update()
print('The date map updated')
