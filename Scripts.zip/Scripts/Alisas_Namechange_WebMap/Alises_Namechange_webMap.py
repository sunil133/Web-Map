import csv
import arcpy
import os
import os.path
csv_name  ='SampleCSV1.csv'

if os.path.exists(csv_name):
    print ('reading csv file....')
    file = open(csv_name)
    csvreader = csv.reader(file)
    header = next(csvreader)
    Layer_Config = {}
    for row in csvreader:
        print(row)
        LayerName = row[0]
        FieldName = row[1]
        visible = row[2]
        if  visible.upper()== 'YES':
            if LayerName not in Layer_Config.keys():
                Layer_Config[LayerName] =[]
            Layer_Config[LayerName].append(FieldName)
    file.close() 
    print(Layer_Config)

    runOnlyActiveMap =True
    # List maps in project and layers in maps
    aprx = arcpy.mp.ArcGISProject('CURRENT')
    print(f'CURRENT MAP-{aprx.activeMap.name}')
    maps  = [aprx.activeMap]
    if runOnlyActiveMap == False:
        maps = aprx.listMaps()
    # Initiate loop through maps and layers
    for map in maps:
        layers = map.listLayers()
        for lyr in layers:
            print(f'layername {lyr} isFeatureLayer -{lyr.isFeatureLayer} isGroupLayer-{lyr.isGroupLayer}')
            print(f'isFeatureLayer -{lyr.isFeatureLayer} isGroupLayer-{lyr.isGroupLayer}')
            if lyr.isFeatureLayer:
                if lyr.name in Layer_Config:
                    visibleFields = Layer_Config[lyr.name]
                    print(visibleFields)
                    cim = lyr.getDefinition('V2')
                    fd = cim.featureTable.fieldDescriptions 
                    if fd != []:
                        print ('fieldDescriptions')
                        List_FieldOrder = []
                        for config_field in visibleFields:
                            print (f'config_field-{config_field}')
                            for fd in cim.featureTable.fieldDescriptions:
                                if fd.fieldName == config_field:
                                    print (f'fd.fieldName -{fd.fieldName}')
                                    fd.visible = True
                                    List_FieldOrder.append(fd)
                                    
                        for fd in cim.featureTable.fieldDescriptions:
                            if fd.fieldName not in visibleFields:
                                 fd.visible = False
                                 List_FieldOrder.append(fd)
                        cim.featureTable.fieldDescriptions =List_FieldOrder
                        lyr.setDefinition(cim)
                    else:
                        name = lyr.name +'_new'
                        field_info = arcpy.Describe(lyr).fieldInfo
                        for index in range(0, field_info.count):
                            #print (field_info.getfieldname(index))
                            if field_info.getfieldname(index) not in visibleFields:
                                # VISIBLE —Field is visible.
                                # HIDDEN —Field is hidden.
                                field_info.setvisible(index,"HIDDEN")
                                print (field_info.getfieldname(index))
                    
                        refLyr = arcpy.MakeFeatureLayer_management(lyr, name, '', '', field_info)
                        refLyr.name = name
                        arcpy.ApplySymbologyFromLayer_management(refLyr, lyr)
                        #arcpy.mp.UpdateLayer(map, lyr, refLyr, False)#update property not in arcpro
                        
                        refLyr.visible = lyr.visible
                        if lyr.transparency:
                            refLyr.transparency = lyr.transparency
                        if lyr.minThreshold:
                            refLyr.minThreshold = lyr.minThreshold
                        if lyr.maxThreshold:
                            refLyr.maxThreshold = lyr.maxThreshold
                        #remove source layer from map
                        moveLayer_= map.listLayers(name)[0]
                        moveLayer_.visible = lyr.visible
                        moveLayer_.name = lyr.name
                        map.moveLayer (lyr, moveLayer_,"AFTER")
                        map.removeLayer( lyr)
                        print (f'{moveLayer_} -Done')
    

print ('All Process Done')

    
    
   
