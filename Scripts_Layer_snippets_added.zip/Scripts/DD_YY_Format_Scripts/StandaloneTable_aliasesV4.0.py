import arcpy
import json
import os
from arcpy import env
import urllib
import http.client  as httplib
import urllib.request
import requests
from requests.auth import HTTPBasicAuth
from arcgis.gis import GIS

print ("Test")

try:
    fieldinfoDict = {}
    print ('Started')
    print('Reading Text File Started')
    with open('E:\\Cyient\\Users\\Sunil\\cweb_json\\DD_YY_Format\\Popup_Udate\\Standalone_tables_alises.txt','r') as fldfile:
        for line in fldfile:
           strfld = line.strip()
##           print(strfld)
           dictkey = strfld.split(",")[0]
##           print(dictkey)
           fieldinfoDict[dictkey] = strfld.split(',')[1]
##    for key in fieldinfoDict:
##        print(fieldinfoDict['relationships/1/LOGICALSTATUS2'])
##    fldkeyvalue = 'relationships/1/LOGICALSTATUS4'
##    if fldkeyvalue in fieldinfoDict :
##        print(fieldinfoDict[fldkeyvalue])
##    else:
##        print("No Value")
    print('Reading Text File Completed')
    
    print("Start Post")
##    newfile=r"E:\SWProject\Popup_Update\DEV_Unified_301023_1.json"
    with open('E:\\Cyient\\Users\\Sunil\\cweb_json\\DD_YY_Format\\Popup_Udate\\DEV_Unified_101123.json','r') as f:
       test_file = json.load(f)

      
       for table in test_file['tables']:
          print(table['title'])
          tableName =  table['popupInfo']      
          elevalue=0
          for i, key in enumerate(tableName.keys()):
   ##           print(i)
   ##           print(key)
              if key == "popupElements":
                  print(key)
                  tableName =  table['popupInfo']['popupElements']
                  elevalue=1
                  for i in tableName:
   ##                   print("ABCD   :",i)
                      if i == "popupElements":
                          tableName =  table['popupInfo']['popupElements']['popupElements']
   ##                       print("tableinfo  :",tableName)
                          for i in tableName:
   ##                           print("ABC:  ",i)
                              for key in i:
                                  if key  == "fieldInfos":
                                      print('Field : ',key)
   ##                                   print(key)
                                      tableName = table['popupInfo']['popupElements']['popupElements'][0]['fieldInfos']
                                      tableField = table['popupInfo']['fieldInfos']
   ##                                   print (tableName[0]['fieldName'])
                      else:
                          for key in i:
                              if key  == "fieldInfos":
                                  print('Field : ',key)
   ##                                   print(key)
                                  tableName = table['popupInfo']['popupElements'][0]['fieldInfos']
                                  tableField = table['popupInfo']['fieldInfos']
   ##                               print (tableName[0]['fieldName'])
              elif key == "fieldInfos" and elevalue == 0:
                  print("Value  : ",key)
                  tableName =  table['popupInfo']['fieldInfos']
   ##               print (tableName[0]['fieldName'])

          fldindex = 0
          for fld in tableName:
              print(tableName[fldindex]['fieldName'])
              print(tableName[fldindex]['label'])
              fldkeyvalue = tableName[fldindex]['fieldName']
              if fldkeyvalue in fieldinfoDict :
                  tableName[fldindex]['label'] = fieldinfoDict[fldkeyvalue]
##              if tableName[fldindex]['fieldName'] == "relationships/1/LOGICALSTATUS":
##                  tableName[fldindex]['label'] = "Logical Status 123"
              fldindex = fldindex + 1
                                                               
          fieldind = 0
          for fld in tableField:
              print(tableField[fieldind]['fieldName'])
              print(tableField[fieldind]['label'])
              fldkeyvalue = tableField[fieldind]['fieldName']
              if fldkeyvalue in fieldinfoDict :
                  tableField[fieldind]['label'] = fieldinfoDict[fldkeyvalue]
              fieldind = fieldind + 1          
          print("===============================================================")
       with open('E:\\Cyient\\Users\\Sunil\\cweb_json\\DD_YY_Format\\Popup_Udate\\DEV_Unified_301023_7.json','w') as jsonfile1:
##           print(test_file)
           json.dump(test_file,jsonfile1,indent=4)
           jsonfile1.close()

except Exception as inst:
    print("Error  :",inst)

print ('Completed')
    
