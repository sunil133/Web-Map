import arcpy
import json
import os
from arcpy import env
import urllib
import http.client  as httplib
import urllib.request
import requests
from requests.auth import HTTPBasicAuth
from arcgis.gis import GIS

##This script reads the web Map json file and update the missing snippets for both operation layers and tabels
##input parameters are Web Map json file
##Script loops through all operation layers and table will insert the new snippets


print ("Test")

# Below are the snippets for operation layers
strLastUpdatedDate ={"fieldName": "LAST_UPDATED_DATE","visible": False,"label": "Last Update Date","format": {"dateFormat": "shortDateLE"}}
strSystemDate = {"fieldName": "SYSTEM_DATE","visible": False,"label": "System Date","format": {"dateFormat": "shortDateLE"}}
strStatusDate = {"fieldName": "STATUSDATE","visible": False,"label": "Status Date","format": {"dateFormat": "shortDateLE"}}
strCreatedDate = {"fieldName": "CREATED_DATE","visible": False,"label": "Created Date","format": {"dateFormat": "shortDateLE"}}
strLastEditedDate = {"fieldName": "LAST_EDITED_DATE","visible": False,"label": "Last Edited Date","format": {"dateFormat": "shortDateLE"}}
strOwnerShipReviewDate = {"fieldName": "OWNERSHIPREVIEWDATE","visible": False,"label": "OWNERSHIP REVIEW DATE","format": {"dateFormat": "shortDateLE"}}
strLongitudex = {"fieldName": "LONGITUDEX","visible": False,"label": "X","format": {"places": 0,"digitSeparator": False}}
strLatitudey = {"fieldName": "LATITUDEY","visible": False,"label": "Y","format": {"places": 0,"digitSeparator": False}}
strGroupLastUpdate = {"fieldName": "LASTUPDATE","visible": False,"label": "Last Update","format": {"dateFormat": "shortDateLE"}}
strPSRConLastUpdate = {"fieldName": "LASTUPDATE","visible": False,"label": "Last Update","format": {"dateFormat": "shortDateLE"}}
strTableLastUpdate = {"fieldName": "LASTUPDATEDATE","visible": False,"label": "Last Update Date","format": {"dateFormat": "shortDateLE"}}
strEasting = {"fieldName": "EASTING","isEditable": True,"format": {"places": 0,"digitSeparator": False},"visible": False,"label":"Easting"}
strNorthing = {"fieldName": "NORTHING","isEditable": True,"format": {"places": 0,"digitSeparator": False},"visible": False,"label": "Northing"}
strLastEditDate = {"fieldName": "LASTEDITEDDATE","visible": False,"label": "Last Edited Date","format": {"dateFormat": "shortDateLE"}}
strCreationDate = {"fieldName": "CREATIONDATE","visible": False,"label": "Creation Date","format": {"dateFormat": "shortDateLE"}}
strGISDate = {"fieldName": "GIS_DATE","visible": False,"label": "GIS Date","format": {"dateFormat": "shortDateLE"}}
strLastUpdateDate ={"fieldName": "LAST_UPDATE_DATE","visible": False,"label": "Last Update Date","format": {"dateFormat": "shortDateLE"}}
strIOW = [{"fieldName": "GISDATE","visible": False,"label": "GISDATE","format": {"dateFormat": "shortDateLE"}},{"fieldName": "DATE_END","isEditable": True,"label": "Date End","format": {"dateFormat": "shortDateLE"}},{"fieldName": "DATE_OF_S","isEditable": True,"label": "Date of S","format": {"dateFormat": "shortDateLE"}},{"fieldName": "DATE_OF_SO","isEditable": True,"label": "Date of SO","format": {"dateFormat": "shortDateLE"}},{"fieldName": "DATE_OF_1","isEditable": True,"label": "Date of 1","format": {"dateFormat": "shortDateLE"}},{"fieldName": "DATENI","isEditable": True,"label": "Date In","format": {"dateFormat": "shortDateLE"}},{"fieldName": "DATEFC","isEditable": True,"label": "Date Fc","format": {"dateFormat": "shortDateLE"}},{"fieldName": "DATEES1","isEditable": True,"label": "Date ES1","format": {"dateFormat": "shortDateLE"}},{"fieldName": "DATEES2","isEditable": True,"label": "Date ES2","format": {"dateFormat": "shortDateLE"}},{"fieldName": "DATEES3","isEditable": True,"label": "Date ES3","format": {"dateFormat": "shortDateLE"}},{"fieldName": "DATECSS","isEditable": True,"label": "Date CSS","format": {"dateFormat": "shortDateLE"}},{"fieldName": "MGTPLANSTA","isEditable": True,"label": "Mgt Plan Rev","format": {"dateFormat": "shortDateLE"}},{"fieldName": "MGTPLANREV","isEditable": True,"label": "Mgt Plan Rev","format": {"dateFormat": "shortDateLE"}}]
strPumpCon = [{"fieldName": "X1","isEditable": True,"format": {"places": 0,"digitSeparator": False},"visible": False,"label": "X1"},{"fieldName": "X2","isEditable": True,"format": {"places": 0,"digitSeparator": False},"visible": False,"label": "X2"},{"fieldName": "Y1","isEditable": True,"format": {"places": 0,"digitSeparator": False},"visible": False,"label": "Y1"},{"fieldName": "Y2","isEditable": True,"format": {"places": 0,"digitSeparator": False},"visible": False,"label": "Y2"}]

#Below are the snippets from Tables
strEntryDate = {"fieldName": "ENTRYDATE","visible": False,"label": "Entry Date","format": {"dateFormat": "shortDateLE"}}
strStartLatitude = {"fieldName": "STREETSTARTLAT","visible": False,"label": "Start Northing","format": {"places": 0,"digitSeparator": False}}
strStartLongitude = {"fieldName": "STREETSTARTLONG","visible": False,"label": "Start Easting","format": {"places": 0,"digitSeparator": False}}
strEndLatitude = {"fieldName": "STREETENDLAT","visible": False,"label": "End Northing","format": {"places": 0,"digitSeparator": False}}
strEndLongitude = {"fieldName": "STREETENDLONG","visible": False,"label": "End Easting","format": {"places": 0,"digitSeparator": False}}
strStartDate = {"fieldName": "STARTDATE","visible": False,"label": "Start Date","format": {"dateFormat": "shortDateLE"}}
strEndDate = {"fieldName": "ENDDATE","visible": False,"label": "End Date","format": {"dateFormat": "shortDateLE"}}

#Below are the list of s layers
strMaximoLayers = "MX-WRP-Planned-Open,MX-WRP-Reactive-Closed,MX-WRP-Reactive-Open,MX-WRP-Planned-Open,MX-WRP-Planned-Closed,MX-WNC-Reactive-Open,MX-WNC-Reactive-Closed,MX-WNC-Planned-Open,MX-WNC-Planned-Closed,MX-WL-Reactive-Open,MX-WL-Reactive-Closed,MX-WL-Planned-Open,MX-WL-Planned-Closed,MX-WWN-Reactive-Open,MX-WWN-Reactive-Closed,MX-WWN-Planned-Open,MX-WWN-Planned-Closed,MX-WWT-Reactive-Open,MX-WWT-Reactive-Closed,MX-WWT-Planned-Open,MX-WWT-Planned-Closed"
strMaximoWatWastLayers = "WRP-Reactive-Open,WRP-Reactive-Closed,WRP-Planned-Open,WRP-Planned-Closed,WNC-Reactive-Open,WNC-Reactive-Closed,WNC-Planned-Open,WNC-Planned-Closed,WL-Reactive-Open,WL-Reactive-Closed,WL-Planned-Open,WL-Planned-Closed,WWN-Reactive-Open,WWN-Reactive-Closed,WWN-Planned-Open,WWN-Planned-Closed,WWT-Reactive-Open,WWT-Reactive-Closed,WWT-Planned-Open,WWT-Planned-Closed"
strAddressLayers = "Current,Provisional,Historic,Other"
strAssetGroupLayers = "{ASSETGROUP},Monitoring Point,Sewer Level Monitor"
strContactLayers = "Water Contact,Wastewater Contact"
strLayer = "Monitoring Point,Sewer Level Monitor"
strPSRContact = "Wastewater PSR - P3,Wastewater PSR - P2,Wastewater PSR - P1,Water PSR - P3,Water PSR - P2,Water PSR - P1"
strPipeBridgeLayer = "Pipe Bridge Wastewater ,Pipe Bridge Water "
strEnvLayers = "Special Protection Area,Special Area of Conservation,Ramsar Site,Site of Special Scientific Interest,National Nature Reserve,Local Wildlife Site - Sussex"
strSectionLayers = "Build Over Agreement,Section 104"
strPumpConLayers = "Pumping Station Connectivity"


strlyrtype = "NoLayer"

#Below function will update the missing snippets in the operation layers
def AddSnippetToLayers():
    try:
        
        print ('Operational Layers process Started')

        with open('E:\\SWProject\\Popup_Update\\latest_DEV_DD_YY_testing.json','r') as f:
           test_file = json.load(f)
           for oplayer in test_file['operationalLayers']:
    ##          print(oplayer['title'])
              strlyrtype = ""
              for i, key in enumerate(oplayer.keys()):
                  if key == "popupInfo":
                      layerName =  oplayer['popupInfo']
                      for i in layerName:
                          if i == "title":
                              strtitle = layerName['title']
                              if strtitle in strMaximoLayers and strtitle[:2] == "MX":
                                  print("MX layers:  ",layerName['title'])
                                  strlyrtype = "MxLayers"
                                  JSONUpdate = layerName['popupElements'][0]['fieldInfos']
                                  JSONFldUpdate = layerName['fieldInfos']
                              elif strtitle in strMaximoLayers and strtitle[:2] != "MX":
                                  print("MX W & WW Layers:  ",layerName['title'])
                                  strlyrtype = "MxWLayers"
                                  JSONUpdate = layerName['popupElements'][0]['fieldInfos']
                                  JSONFldUpdate = layerName['fieldInfos']
                              elif strtitle in strAssetGroupLayers:
                                  print("AssetGroup:  ",layerName['title'])
                                  strlyrtype = "AstGrpLayers"
                                  optLayerNameFlds = layerName['popupElements'][0]['fieldInfos']
                                  fldindex = 0
                                  for fld in optLayerNameFlds:
    ##                                  print("To Check if it is water or waste water Layer")
                                      fldkeyvalue = optLayerNameFlds[fldindex]['fieldName']
                                      if fldkeyvalue == "WASTEWATERUSE":
                                          strlyrtype = "AstGrpLayersWW"
                                          print("Waste Water Layer")
                                          break
                                      fldindex = fldindex + 1
                                  JSONUpdate = layerName['popupElements'][0]['fieldInfos']
                                  JSONFldUpdate = layerName['fieldInfos']
                              elif strtitle in strAddressLayers:
                                  print("Address Name:  ",layerName['title'])
                                  strlyrtype = "AddrLayers"
                                  JSONUpdate = layerName['popupElements'][0]['fieldInfos']
                                  JSONFldUpdate = layerName['fieldInfos']
                              elif strtitle == "Local Wildlife Site - loW":
                                  print("IOW Layer:  ",layerName['title'])
                                  strlyrtype = "Local Wildlife Site - loW"
                                  JSONUpdate = layerName['popupElements'][0]['fieldInfos']
                                  JSONFldUpdate = layerName['fieldInfos']                                    
                              elif strtitle in strPipeBridgeLayer:
                                  print("Pipe Bridge:  ",layerName['title'])
                                  strlyrtype = "PipeBridgeLayers"
                                  JSONUpdate = layerName['popupElements'][0]['fieldInfos']
                                  JSONFldUpdate = layerName['fieldInfos']                                  
                              elif strtitle in strPSRContact:
                                  print("PSR Contact Layers:  ",layerName['title'])
                                  strlyrtype = "PSRLayers"
                                  JSONUpdate = layerName['popupElements'][0]['fieldInfos']
                                  JSONFldUpdate = layerName['fieldInfos']                                   
                              elif strtitle in strPumpConLayers:
                                  print("Pump Connectivity Layers:  ",layerName['title'])
                                  strlyrtype = "PumpConLayers"
                                  JSONUpdate = layerName['popupElements'][0]['fieldInfos']
                                  JSONFldUpdate = layerName['fieldInfos']                                  
                              elif strtitle in strEnvLayers:
                                  print("Environment Layers:  ",layerName['title'])
                                  strlyrtype = "EnvironmentLayers"
                                  JSONUpdate = layerName['popupElements'][0]['fieldInfos']
                                  JSONFldUpdate = layerName['fieldInfos']
                              elif strtitle in strSectionLayers:
                                  print("Section  Layers:  ",layerName['title'])
                                  strlyrtype = "SectionLayers"
                                  JSONUpdate = layerName['popupElements'][0]['fieldInfos']
                                  JSONFldUpdate = layerName['fieldInfos']                                    
                              elif strtitle in strContactLayers:
                                  strlyrtype = "ContactLayers"
                                  optLayerNameFlds = layerName['popupElements'][0]['fieldInfos']
                                  fldindex = 0
                                  for fld in optLayerNameFlds:
##                                      print("Change in Date Format")
                                      fldkeyvalue = optLayerNameFlds[fldindex]['fieldName']
                                      if fldkeyvalue == "ENQ_DATE":
                                          optLayerNameFlds[fldindex]['format']['dateFormat'] = "shortDateLEShortTime24"
##                                          print("Date Format Updated")
                                      fldindex = fldindex + 1
                                  optLayerNameFlds = layerName['fieldInfos']
                                  fldindex = 0
                                  for fld in optLayerNameFlds:
##                                      print("Change in Date Format")
                                      fldkeyvalue = optLayerNameFlds[fldindex]['fieldName']
                                      if fldkeyvalue == "ENQ_DATE":
                                          optLayerNameFlds[fldindex]['format']['dateFormat'] = "shortDateLEShortTime24"
##                                          print("Date Format Updated")
                                      fldindex = fldindex + 1
                                      
              print("================================================")
              if strlyrtype != "NoLayer":
                  if strlyrtype == "MxLayers":
                      JSONUpdate.append(strStatusDate)
                      JSONUpdate.append(strCreatedDate)
                      JSONUpdate.append(strLastEditedDate)
                      JSONUpdate.append(strLongitudex)
                      JSONUpdate.append(strLatitudey)
                      JSONFldUpdate.append(strStatusDate)
                      JSONFldUpdate.append(strCreatedDate)
                      JSONFldUpdate.append(strLastEditedDate)
                      JSONFldUpdate.append(strLongitudex)
                      JSONFldUpdate.append(strLatitudey)
                      print("Update To MxLayers")                 
                  elif strlyrtype == "MxWLayers":
                      JSONUpdate.append(strLastUpdatedDate)
                      JSONUpdate.append(strSystemDate)
                      JSONFldUpdate.append(strLastUpdatedDate)
                      JSONFldUpdate.append(strSystemDate)
                      print("Update To MxWLayers") 
                  elif strlyrtype == "AstGrpLayers":
                      JSONUpdate.append(strGroupLastUpdate)
                      JSONFldUpdate.append(strGroupLastUpdate)
                      print("Update To AstGrpLayers")
                  elif strlyrtype == "Local Wildlife Site - loW":
                      for strelem in strIOW:
                          JSONUpdate.append(strelem)
                          JSONFldUpdate.append(strelem)
                      print("Update To AstGrpLayers")                      
                  elif strlyrtype == "AstGrpLayersWW":
                      JSONUpdate.append(strGroupLastUpdate)
                      JSONUpdate.append(strLastEditedDate)
                      JSONUpdate.append(strOwnerShipReviewDate)                  
                      JSONFldUpdate.append(strGroupLastUpdate)
                      JSONFldUpdate.append(strLastEditedDate)
                      JSONFldUpdate.append(strOwnerShipReviewDate)
                      print("Update To Waste water AstGrpLayers")
                  elif strlyrtype == "PSRLayers":
                      JSONUpdate.append(strPSRConLastUpdate)
                      JSONFldUpdate.append(strPSRConLastUpdate)
                      print("Update To PSR Layers")                      
                  elif strlyrtype == "EnvironmentLayers":                     
                      JSONUpdate.append(strGISDate)
                      JSONFldUpdate.append(strGISDate)
                      print("Update To Environment Layers")
                  elif strlyrtype == "PumpConLayers":
                      for strelem in strPumpCon:
                          JSONUpdate.append(strelem)
                          JSONFldUpdate.append(strelem)
                      print("Update To Pump Connection Layers") 
                  elif strlyrtype == "SectionLayers":
                      JSONUpdate.append(strLastUpdateDate)
                      JSONFldUpdate.append(strLastUpdateDate)
                      print("Update To Section Layers")                      
                  elif strlyrtype == "AddrLayers":
                      JSONUpdate.append(strEasting)
                      JSONUpdate.append(strNorthing)
                      JSONFldUpdate.append(strEasting)
                      JSONFldUpdate.append(strNorthing)
                      print("Update To Address Layers")
                  elif strlyrtype == "PipeBridgeLayers":               
                      JSONUpdate.append(strLastEditDate)
                      JSONUpdate.append(strCreationDate)
                      JSONUpdate.append(strTableLastUpdate)
                      JSONFldUpdate.append(strLastEditDate)                      
                      JSONFldUpdate.append(strCreationDate)
                      JSONFldUpdate.append(strTableLastUpdate)
                      print("Update To Pipe Bridge Layers")              

           AddSnippetToTables(test_file)
           print("===============================================================")


           with open('E:\SWProject\Popup_Update\latest_DEV_DD_YY_testing_2.1.json','w') as jsonfile1:
               json.dump(test_file,jsonfile1,indent=4)
    ##           json.dumps(test_file,jsonfile1)
               jsonfile1.close()

    except Exception as inst:
        print("Error  :",inst)

    print ('Updating Operational Layers Completed')
    
##Below function will update the missing snippets in the Table 
def AddSnippetToTables(srcFile):
    try:
        
        print("Add Snippet to Table Process started")
##        test_file = json.load(srcFile)
        for  table in srcFile['tables']:
           print(table['title'])
           strtableName = table['title']
           strtabletype = ""
           if strtableName == "Cross Reference":
               tablePopUpFields = table['popupInfo']['popupElements'][0]['fieldInfos']
               tableFields = table['popupInfo']['fieldInfos']
               tablePopUpFields.append(strStartDate)
               tablePopUpFields.append(strEndDate)
               tablePopUpFields.append(strTableLastUpdate)
               tablePopUpFields.append(strEntryDate)
               tableFields.append(strStartDate)               
               tableFields.append(strEndDate)              
               tableFields.append(strTableLastUpdate) 
               tableFields.append(strEntryDate)                 
           elif strtableName == "Street":
               tablePopUpFields = table['popupInfo']['popupElements'][0]['fieldInfos']
               tableFields = table['popupInfo']['fieldInfos']
               tablePopUpFields.append(strStartLatitude)
               tablePopUpFields.append(strStartLongitude)
               tablePopUpFields.append(strEndLatitude)
               tablePopUpFields.append(strEndLongitude)
               tablePopUpFields.append(strStartDate)
               tablePopUpFields.append(strEndDate)
               tablePopUpFields.append(strTableLastUpdate)
               tablePopUpFields.append(strEntryDate)
               tableFields.append(strStartLatitude)
               tableFields.append(strStartLongitude)
               tableFields.append(strEndLatitude)
               tableFields.append(strEndLongitude)
               tableFields.append(strStartDate)               
               tableFields.append(strEndDate)              
               tableFields.append(strTableLastUpdate) 
               tableFields.append(strEntryDate)               
           elif strtableName == "Supplementary":
               tablePopUpFields = table['popupInfo']['popupElements'][0]['fieldInfos']
               tableFields = table['popupInfo']['fieldInfos']
               tablePopUpFields.append(strTableLastUpdate)
               tablePopUpFields.append(strEntryDate)
               tableFields.append(strTableLastUpdate) 
               tableFields.append(strEntryDate)                 
           elif strtableName == "Classification":
               tablePopUpFields = table['popupInfo']['popupElements'][0]['fieldInfos']
               tableFields = table['popupInfo']['fieldInfos']
               tablePopUpFields.append(strTableLastUpdate)
               tablePopUpFields.append(strEntryDate)
               tableFields.append(strTableLastUpdate) 
               tableFields.append(strEntryDate)                 
           elif strtableName == "Delivery Point Address":
               tablePopUpFields = table['popupInfo']['popupElements'][0]['fieldInfos']
               tableFields = table['popupInfo']['fieldInfos']
               tablePopUpFields.append(strTableLastUpdate)
               tablePopUpFields.append(strEntryDate)
               tableFields.append(strTableLastUpdate) 
               tableFields.append(strEntryDate)                  
           print("================================================")
           
        print("===============================================================")

    except Exception as inst:
        print("Error  :",inst)

    
# Main module
#
def main():
    try:
        AddSnippetToLayers()
    except exception as e:
        print("Errors   :  ",e)
    print("Process Completed")    
if __name__ == "__main__":
    main()
